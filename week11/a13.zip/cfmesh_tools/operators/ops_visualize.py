import bpy
import os
from .ops_utils import set_ui_error, clear_ui_status
from ..properties import global_state
from .. import utils_system

def load_vtp_mesh(context, vtp_path, field_name, mesh_name_prefix, operator, target_collection=None):
    import math
    import xml.etree.ElementTree as ET
    
    try:
        tree = ET.parse(vtp_path)
        root = tree.getroot()
        
        polydata = root.find('PolyData')
        if polydata is None: raise Exception("Missing <PolyData>")
        piece = polydata.find('Piece')
        if piece is None: raise Exception("Missing <Piece>")
        
        # Points
        points_elem = piece.find('Points/DataArray')
        if points_elem is None or not points_elem.text: 
            raise Exception("Slice is completely outside the mesh bounds (0 points).")
        raw_points = [float(x) for x in points_elem.text.split()]
        if not raw_points:
            raise Exception("Slice is completely outside the mesh bounds (0 points).")
        vertices = [(raw_points[i], raw_points[i+1], raw_points[i+2]) for i in range(0, len(raw_points), 3)]
        
        # Polys
        conn_elem = piece.find('Polys/DataArray[@Name="connectivity"]')
        offsets_elem = piece.find('Polys/DataArray[@Name="offsets"]')
        if conn_elem is None or offsets_elem is None: raise Exception("Missing Polys DataArrays")
        
        connectivity = [int(x) for x in conn_elem.text.split()]
        offsets = [int(x) for x in offsets_elem.text.split()]
        
        faces = []
        start_idx = 0
        for offset in offsets:
            face = connectivity[start_idx:offset]
            faces.append(tuple(face))
            start_idx = offset
            
        # Data (CellData or PointData)
        is_cell_data = True
        data_elem = piece.find(f'CellData/DataArray[@Name="{field_name}"]')
        if data_elem is None:
            data_elem = piece.find(f'PointData/DataArray[@Name="{field_name}"]')
            is_cell_data = False
            
        if data_elem is None:
            raise Exception(f"Field {field_name} not found in VTK Data.")
            
        raw_data = [float(x) for x in data_elem.text.split()]
        
        values = []
        is_vector = data_elem.get('NumberOfComponents') == '3'
        if is_vector:
            for i in range(0, len(raw_data), 3):
                mag = math.sqrt(raw_data[i]**2 + raw_data[i+1]**2 + raw_data[i+2]**2)
                values.append(mag)
        else:
            values = raw_data
            
    except Exception as e:
        operator.report({'ERROR'}, f"Failed to parse VTK: {e}")
        from .ops_utils import set_ui_error
        set_ui_error(f"VTK Parse Error: {str(e)[:50]}")
        return None
        
    # Create Blender Mesh
    import bpy
    mesh = bpy.data.meshes.new(mesh_name_prefix)
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    
    obj = bpy.data.objects.new(mesh_name_prefix, mesh)
    if target_collection:
        target_collection.objects.link(obj)
    else:
        context.collection.objects.link(obj)
    
    # Deselect all, select new object
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj
    
    # Apply Colors
    color_layer_name = f"CFD_{field_name}"
    color_layer = mesh.color_attributes.new(name=color_layer_name, type='FLOAT_COLOR', domain='CORNER')
    mesh.color_attributes.active_color = color_layer
    
    if len(values) > 0:
        props = context.scene.cfmesh_props
        if props.color_autoscale:
            vmin = min(values)
            vmax = max(values)
        else:
            vmin = props.color_min
            vmax = props.color_max
            
        val_range = vmax - vmin if vmax != vmin else 1.0
        
        if is_cell_data:
            for face_idx, poly in enumerate(mesh.polygons):
                val = values[face_idx] if face_idx < len(values) else 0.0
                t = (val - vmin) / val_range
                color = OBJECT_OT_ColorByField.jet_colormap(t) + (1.0,)
                for loop_idx in poly.loop_indices:
                    color_layer.data[loop_idx].color = color
        else:
            for poly in mesh.polygons:
                for loop_idx in poly.loop_indices:
                    vert_idx = mesh.loops[loop_idx].vertex_index
                    val = values[vert_idx] if vert_idx < len(values) else 0.0
                    t = (val - vmin) / val_range
                    color = OBJECT_OT_ColorByField.jet_colormap(t) + (1.0,)
                    color_layer.data[loop_idx].color = color
                
    # Apply a UNIQUE material per object so colors don't bleed between meshes
    mat_name = f"CFD_Mat_{mesh_name_prefix}"
    mat = bpy.data.materials.new(name=mat_name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    
    output_node = nodes.new('ShaderNodeOutputMaterial')
    output_node.location = (400, 0)
    
    bsdf_node = nodes.new('ShaderNodeBsdfPrincipled')
    bsdf_node.location = (200, 0)
    
    vcol_node = nodes.new('ShaderNodeVertexColor')
    vcol_node.location = (0, 0)
    vcol_node.layer_name = color_layer_name
    
    links.new(vcol_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])
    
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)
        
    # Switch to Material Preview
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    space.shading.type = 'MATERIAL'
                    
    return obj


class OBJECT_OT_ColorByField(bpy.types.Operator):
    bl_idname = "object.color_by_field"
    bl_label = "Color Mesh by Field"
    bl_description = "Uses foamToVTK to sample fields onto boundaries and creates a colored mesh"
    
    def execute(self, context):
        import os
        import bpy
        from .. import utils_system
        from ..properties import global_state
        from .ops_utils import clear_ui_status, set_ui_error

        props = context.scene.cfmesh_props
        case_dir = bpy.path.abspath(props.export_dir)
        field_name = props.color_field if props.color_field != 'U_mag' else 'U'
        
        # --- Validation ---
        if not os.path.isdir(case_dir):
            self.report({'ERROR'}, "Case directory not found.")
            set_ui_error("Case directory not found.")
            return {'CANCELLED'}
            
        clear_ui_status()
        global_state.status_message = "Running foamToVTK..."
        
        # 1. Run foamToVTK
        source_cmd = "source /usr/lib/openfoam/openfoam2412/etc/bashrc"
        is_quality_field = props.color_field in ('nonOrthoAngle', 'skewness')
        
        if is_quality_field:
            # Force OpenFOAM to generate the fields first
            utils_system.run_cfmesh_command(f"{source_cmd} && checkMesh -writeAllFields -time 0", case_dir)
            # Force OpenFOAM to include the quality fields in the VTK export
            command = f"{source_cmd} && foamToVTK -no-internal -one-boundary -ascii -time 0 -fields '(p U {props.color_field})'"
        elif props.animate_results:
            command = f"{source_cmd} && foamToVTK -no-internal -one-boundary -ascii"
        else:
            command = f"{source_cmd} && foamToVTK -no-internal -one-boundary -ascii -latestTime"
            
        success, output = utils_system.run_cfmesh_command(command, case_dir)
        
        if not success:
            self.report({'ERROR'}, "foamToVTK failed. Check solver logs.")
            set_ui_error("foamToVTK execution failed.")
            return {'CANCELLED'}
            
        # 2. Locate boundary.vtp files
        vtk_dir = os.path.join(case_dir, "VTK")
        if not os.path.isdir(vtk_dir):
            self.report({'ERROR'}, "VTK directory not generated.")
            set_ui_error("VTK directory missing.")
            return {'CANCELLED'}
            
        time_vtps = []
        for d in os.listdir(vtk_dir):
            time_dir = os.path.join(vtk_dir, d)
            if os.path.isdir(time_dir):
                # VTK dirs are named like "cfmesh_run_500" — grab the last segment
                last_part = d.rsplit('_', 1)[-1]
                try:
                    t = float(last_part)
                    vtp_path = os.path.join(time_dir, "boundary.vtp")
                    if os.path.isfile(vtp_path):
                        time_vtps.append((t, vtp_path))
                except ValueError:
                    continue
                    
        if not time_vtps:
            self.report({'ERROR'}, "boundary.vtp not found in VTK output.")
            set_ui_error("boundary.vtp not found.")
            return {'CANCELLED'}
            
        time_vtps.sort(key=lambda x: x[0])
        
        if not props.animate_results:
            time_vtps = [time_vtps[-1]]
            
        # 3. Create collection if animating
        anim_col = None
        if props.animate_results and len(time_vtps) > 1:
            col_name = f"CFD_Anim_Boundary_{props.color_field}"
            anim_col = bpy.data.collections.new(col_name)
            context.scene.collection.children.link(anim_col)
            
        # 4. Load Meshes
        objects = []
        for t, vtp_path in time_vtps:
            mesh_name = f"CFD_Boundary_t{t}_{props.color_field}"
            obj = load_vtp_mesh(context, vtp_path, field_name, mesh_name, self, target_collection=anim_col)
            if obj:
                objects.append(obj)
                
        # 5. Animate
        if props.animate_results and len(objects) > 1:
            context.scene.frame_start = 1
            context.scene.frame_end = len(objects)
            
            for frame, obj in enumerate(objects, start=1):
                obj.hide_viewport = True
                obj.hide_render = True
                obj.keyframe_insert(data_path="hide_viewport", frame=frame-1)
                obj.keyframe_insert(data_path="hide_render", frame=frame-1)
                
                obj.hide_viewport = False
                obj.hide_render = False
                obj.keyframe_insert(data_path="hide_viewport", frame=frame)
                obj.keyframe_insert(data_path="hide_render", frame=frame)
                
                obj.hide_viewport = True
                obj.hide_render = True
                obj.keyframe_insert(data_path="hide_viewport", frame=frame+1)
                obj.keyframe_insert(data_path="hide_render", frame=frame+1)
                
            global_state.status_message = f"Animation Created: {len(objects)} frames"
            self.report({'INFO'}, f"Animation created with {len(objects)} frames.")
        elif objects:
            t = time_vtps[0][0]
            field_label = "Pressure" if props.color_field == 'p' else "Velocity Magnitude"
            global_state.status_message = f"Colored by {field_label} (t={t})"
            self.report({'INFO'}, f"Visualization created for {field_label}")
            
        return {'FINISHED'}

    @staticmethod
    def jet_colormap(t):
        """Convert 0-1 value to RGB using jet colormap (Blue→Cyan→Green→Yellow→Red)."""
        t = max(0.0, min(1.0, t))
        if t < 0.25:
            r, g, b = 0.0, t * 4, 1.0
        elif t < 0.5:
            r, g, b = 0.0, 1.0, 1.0 - (t - 0.25) * 4
        elif t < 0.75:
            r, g, b = (t - 0.5) * 4, 1.0, 0.0
        else:
            r, g, b = 1.0, 1.0 - (t - 0.75) * 4, 0.0
        return r, g, b

class OBJECT_OT_VisualizeSlice(bpy.types.Operator):
    bl_idname = "object.visualize_slice"
    bl_label = "Visualize Slice Plane"
    bl_description = "Extracts an internal slice plane using OpenFOAM and visualizes it"
    
    def execute(self, context):
        import os
        import bpy
        from .. import utils_system
        from ..properties import global_state
        from .ops_utils import clear_ui_status, set_ui_error

        props = context.scene.cfmesh_props
        case_dir = bpy.path.abspath(props.export_dir)
        field_name = props.color_field if props.color_field != 'U_mag' else 'U'
        
        if not os.path.isdir(case_dir):
            self.report({'ERROR'}, "Case directory not found.")
            set_ui_error("Case directory not found.")
            return {'CANCELLED'}
            
        clear_ui_status()
        global_state.status_message = "Extracting Slice Plane..."
        
        # 1. Generate system/sliceDict
        sys_dir = os.path.join(case_dir, "system")
        if not os.path.exists(sys_dir): os.makedirs(sys_dir)
        
        slice_dict_path = os.path.join(sys_dir, "sliceDict")
        
        # Determine normal and point
        axis = props.slice_axis
        offset = props.slice_offset
        if axis == 'X':
            normal = "(1 0 0)"
            point = f"({offset} 0 0)"
        elif axis == 'Y':
            normal = "(0 1 0)"
            point = f"(0 {offset} 0)"
        else:
            normal = "(0 0 1)"
            point = f"(0 0 {offset})"
            
        # Conditionally include quality fields
        fields_str = "p U k omega epsilon nut"
        if props.checkmesh_write_fields:
            fields_str += " nonOrthoAngle skewness cellLevel"
            
        slice_dict_content = f"""FoamFile
{{
    version     2.0;
    format      ascii;
    class       dictionary;
    object      sliceDict;
}}

functions
{{
    mySlice
    {{
        type            surfaces;
        libs            (sampling);
        writeControl    onEnd;
        surfaceFormat   vtk;
        formatOptions {{ vtk {{ format ascii; }} }}
        fields          ( {fields_str} );

        surfaces
        {{
            slice_plane
            {{
                type            cuttingPlane;
                planeType       pointAndNormal;
                pointAndNormalDict
                {{
                    point   {point};
                    normal  {normal};
                }}
                interpolate     true;
            }}
        }}
    }}
}}
"""
        with open(slice_dict_path, 'w') as f:
            f.write(slice_dict_content)
            
        # 2. Run postProcess
        source_cmd = "source /usr/lib/openfoam/openfoam2412/etc/bashrc"
        is_quality_field = props.color_field in ('nonOrthoAngle', 'skewness')
        
        fields_arg = "p U k omega epsilon nut"
        if props.checkmesh_write_fields:
            fields_arg += " nonOrthoAngle skewness cellLevel"
            
        if is_quality_field:
            utils_system.run_cfmesh_command(f"{source_cmd} && checkMesh -writeAllFields -time 0", case_dir)
            command = f"{source_cmd} && postProcess -dict system/sliceDict -fields '({fields_arg})' -time 0"
        elif props.animate_results:
            command = f"{source_cmd} && postProcess -dict system/sliceDict -fields '({fields_arg})'"
        else:
            command = f"{source_cmd} && postProcess -dict system/sliceDict -fields '({fields_arg})' -latestTime"
            
        success, output = utils_system.run_cfmesh_command(command, case_dir)
        
        if not success:
            self.report({'ERROR'}, "postProcess slice failed. Check solver logs.")
            set_ui_error("Slice extraction failed.")
            return {'CANCELLED'}
            
        # 3. Locate slice_plane.vtp files — clear stale results first
        post_dir = os.path.join(case_dir, "postProcessing", "mySlice")
        if not os.path.isdir(post_dir):
            self.report({'ERROR'}, "postProcessing directory not generated.")
            set_ui_error("Slice VTK missing.")
            return {'CANCELLED'}
            
        time_vtps = []
        for d in os.listdir(post_dir):
            time_dir = os.path.join(post_dir, d)
            if os.path.isdir(time_dir):
                try:
                    t = float(d)
                    vtp_path = os.path.join(time_dir, "slice_plane.vtp")
                    if os.path.isfile(vtp_path):
                        time_vtps.append((t, vtp_path))
                except ValueError:
                    continue
                    
        if not time_vtps:
            self.report({'ERROR'}, "slice_plane.vtp not found.")
            set_ui_error("slice_plane.vtp not found.")
            return {'CANCELLED'}
            
        time_vtps.sort(key=lambda x: x[0])
        
        if not props.animate_results:
            time_vtps = [time_vtps[-1]]
            
        # 4. Create collection if animating
        anim_col = None
        if props.animate_results and len(time_vtps) > 1:
            col_name = f"CFD_Anim_Slice_{axis}_{offset}_{props.color_field}"
            anim_col = bpy.data.collections.new(col_name)
            context.scene.collection.children.link(anim_col)
            
        # 5. Load Meshes
        objects = []
        for t, vtp_path in time_vtps:
            mesh_name = f"CFD_Slice_{axis}_{offset}_t{t}_{props.color_field}"
            obj = load_vtp_mesh(context, vtp_path, field_name, mesh_name, self, target_collection=anim_col)
            if obj:
                objects.append(obj)
                
        # 6. Animate
        if props.animate_results and len(objects) > 1:
            context.scene.frame_start = 1
            context.scene.frame_end = len(objects)
            
            for frame, obj in enumerate(objects, start=1):
                obj.hide_viewport = True
                obj.hide_render = True
                obj.keyframe_insert(data_path="hide_viewport", frame=frame-1)
                obj.keyframe_insert(data_path="hide_render", frame=frame-1)
                
                obj.hide_viewport = False
                obj.hide_render = False
                obj.keyframe_insert(data_path="hide_viewport", frame=frame)
                obj.keyframe_insert(data_path="hide_render", frame=frame)
                
                obj.hide_viewport = True
                obj.hide_render = True
                obj.keyframe_insert(data_path="hide_viewport", frame=frame+1)
                obj.keyframe_insert(data_path="hide_render", frame=frame+1)
                
            global_state.status_message = f"Animation Created: {len(objects)} frames"
            self.report({'INFO'}, f"Animation created with {len(objects)} frames.")
        elif objects:
            t = time_vtps[0][0]
            field_label = "Pressure" if props.color_field == 'p' else "Velocity Magnitude"
            global_state.status_message = f"Slice Extracted: {field_label} (t={t})"
            self.report({'INFO'}, f"Slice plane created for {field_label}")
            
        return {'FINISHED'}
