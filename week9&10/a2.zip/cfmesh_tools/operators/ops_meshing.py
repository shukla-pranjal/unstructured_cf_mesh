import bpy
import os
from .ops_utils import run_command_async, set_ui_error, clear_ui_status
from ..properties import global_state
from .. import utils_mesh

class OBJECT_OT_RefreshPatches(bpy.types.Operator):
    bl_idname = "object.refresh_patches"
    bl_label = "Refresh Patches"
    bl_description = "Loads all selected objects as independent mesh patches"
    
    def execute(self, context):
        props = context.scene.cfmesh_props
        props.boundary_patches.clear()
        
        objects = context.selected_objects
        if not objects:
            self.report({'WARNING'}, "No objects selected!")
            global_state.status_message = "No objects selected."
            return {'FINISHED'}
            
        for obj in objects:
            if obj.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT'}:
                patch = props.boundary_patches.add()
                patch.name = obj.name
                
        self.report({'INFO'}, f"Loaded {len(props.boundary_patches)} patches.")
        global_state.status_message = f"Loaded {len(props.boundary_patches)} patches."
        return {'FINISHED'}

class OBJECT_OT_ImportSTL(bpy.types.Operator):
    bl_idname = "object.import_stl_geometry"
    bl_label = "Import STL Geometry"
    bl_description = "Import an external STL file as the geometry to mesh"
    
    filepath: bpy.props.StringProperty(
        subtype='FILE_PATH',
        default="",
    )
    
    filter_glob: bpy.props.StringProperty(
        default="*.stl;*.STL",
        options={'HIDDEN'},
    )
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
    def execute(self, context):
        filepath = self.filepath
        
        # --- Validation: File selected ---
        if not filepath:
            self.report({'ERROR'}, "No file selected.")
            set_ui_error("No STL file selected.")
            return {'CANCELLED'}
        
        # --- Validation: File exists ---
        if not os.path.isfile(filepath):
            self.report({'ERROR'}, f"File not found: {filepath}")
            set_ui_error(f"File not found: {os.path.basename(filepath)}")
            return {'CANCELLED'}
        
        # --- Validation: File extension ---
        if not filepath.lower().endswith('.stl'):
            self.report({'ERROR'}, "Only .stl files are supported.")
            set_ui_error("Invalid file type. Only .stl files supported.")
            return {'CANCELLED'}
        
        # --- Validation: File not empty ---
        if os.path.getsize(filepath) == 0:
            self.report({'ERROR'}, "STL file is empty (0 bytes).")
            set_ui_error("STL file is empty.")
            return {'CANCELLED'}
        
        clear_ui_status()
        
        try:
            # Remember existing objects to identify the new one
            existing_objects = set(bpy.data.objects.keys())
            
            bpy.ops.wm.stl_import(filepath=filepath)
            
            # Find the newly imported object(s)
            new_objects = [obj for name, obj in bpy.data.objects.items() 
                         if name not in existing_objects and obj.type == 'MESH']
            
            if new_objects:
                # Select and set active the imported geometry
                bpy.ops.object.select_all(action='DESELECT')
                for obj in new_objects:
                    obj.select_set(True)
                context.view_layer.objects.active = new_objects[0]
                
                # Report stats
                total_verts = sum(len(o.data.vertices) for o in new_objects)
                total_faces = sum(len(o.data.polygons) for o in new_objects)
                name = new_objects[0].name
                
                self.report({'INFO'}, 
                    f"Imported '{name}' — {total_verts:,} vertices, {total_faces:,} faces. Ready for meshing.")
                global_state.status_message = f"Imported: {name} ({total_faces:,} faces)"
            else:
                self.report({'WARNING'}, "Import completed but no mesh objects were created.")
                set_ui_error("Import failed — no mesh objects created.")
                return {'CANCELLED'}
                
        except Exception as e:
            self.report({'ERROR'}, f"Import failed: {str(e)}")
            set_ui_error(f"Import error: {str(e)[:50]}")
            return {'CANCELLED'}
        
        return {'FINISHED'}

class OBJECT_OT_GenerateCFMesh(bpy.types.Operator):
    bl_idname = "object.generate_cfmesh"
    bl_label = "Generate cfMesh"
    bl_description = "Exports STL and generates meshDict locally"
    
    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'
        
    def execute(self, context):
        props = context.scene.cfmesh_props
        obj = context.active_object
        
        # --- Guard: Don't stack concurrent runs ---
        if global_state.is_running:
            self.report({'ERROR'}, "A process is already running. Wait for it to finish.")
            set_ui_error("A process is already running. Wait for it to finish.")
            return {'CANCELLED'}
        
        clear_ui_status()
        
        # --- Validation: Object geometry ---
        if not obj or (obj.type == 'MESH' and len(obj.data.polygons) == 0):
            self.report({'ERROR'}, "The selected active object has no geometry.")
            set_ui_error("Selected object has no geometry.")
            return {'CANCELLED'}
        
        # --- Validation: Cell size sanity ---
        if props.base_cell_size < 0.01:
            self.report({'ERROR'}, f"Cell size {props.base_cell_size} is too small. This would generate millions of cells. Use >= 0.01.")
            set_ui_error(f"Cell size {props.base_cell_size} too small (min 0.01).")
            return {'CANCELLED'}
        
        if props.base_cell_size > 5.0:
            self.report({'WARNING'}, "Cell size is very large — the mesh may be too coarse to capture geometry.")
        
        # --- Validation: Boundary layer params ---
        if props.boundary_layers > 10:
            self.report({'WARNING'}, "High boundary layer count (>10) may cause mesh quality issues.")
            
        if props.boundary_layers > 0 and props.layer_thickness <= 1.0:
            self.report({'WARNING'}, "Thickness ratio should be > 1.0 for boundary layer expansion.")
            
        if context.active_object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
            
        try:
            case_dir = bpy.path.abspath(props.export_dir)
            
            # --- Validation: Export directory ---
            if not case_dir or case_dir.strip() in ("", "/"):
                self.report({'ERROR'}, "Export directory is empty or invalid.")
                set_ui_error("Export directory is empty or invalid.")
                return {'CANCELLED'}
            
            # Normalize the path
            case_dir = os.path.normpath(case_dir)
            
            # Walk up the path to find deepest existing ancestor
            # Reject if more than 1 level needs creation (prevents /abc/xyz/fake)
            check_path = case_dir
            levels_missing = 0
            while check_path and check_path != os.path.dirname(check_path):
                if os.path.exists(check_path):
                    break
                levels_missing += 1
                check_path = os.path.dirname(check_path)
            
            if levels_missing > 1:
                self.report({'ERROR'}, f"Invalid path — too many missing directories: {case_dir}")
                set_ui_error(f"Invalid path: {case_dir}")
                return {'CANCELLED'}
                
            os.makedirs(case_dir, exist_ok=True)
            if not os.access(case_dir, os.W_OK):
                self.report({'ERROR'}, f"Cannot write to export directory: {case_dir}")
                set_ui_error(f"No write permission: {case_dir}")
                return {'CANCELLED'}
            
            success = utils_mesh.create_case_structure(
                base_dir=case_dir,
                cell_size=props.base_cell_size,
                boundary_layers=props.boundary_layers,
                thickness_ratio=props.layer_thickness,
                stl_name="mesh.stl",
                cpu_cores=props.cpu_cores,
                boundary_patches=props.boundary_patches
            )
            
            if not success:
                self.report({'ERROR'}, "Failed to generate OpenFOAM structure.")
                set_ui_error("Failed to generate OpenFOAM case files.")
                return {'CANCELLED'}

            tri_surface_dir = os.path.join(case_dir, "constant", "triSurface")
            os.makedirs(tri_surface_dir, exist_ok=True)
            stl_path = os.path.join(tri_surface_dir, "mesh.stl")
            
            # Multi-patch Selection Logic
            bpy.ops.object.select_all(action='DESELECT')
            active_target = None
            if len(props.boundary_patches) > 0:
                for patch in props.boundary_patches:
                    if patch.name in bpy.data.objects:
                        o = bpy.data.objects[patch.name]
                        o.select_set(True)
                        active_target = o
            else:
                if obj:
                    obj.select_set(True)
                    active_target = obj
                    
            if active_target:
                context.view_layer.objects.active = active_target
            
            # Apply Transforms
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            
            # Triangulate meshes
            for o in context.selected_objects:
                if o.type == 'MESH':
                    context.view_layer.objects.active = o
                    try:
                        bpy.ops.object.modifier_add(type='TRIANGULATE')
                        bpy.ops.object.modifier_apply(modifier=o.modifiers[-1].name)
                    except:
                        pass
            
            bpy.ops.wm.stl_export(
                filepath=stl_path,
                export_selected_objects=True,
                global_scale=1.0
            )
            
            # --- Validation: STL was actually exported ---
            if not os.path.isfile(stl_path) or os.path.getsize(stl_path) == 0:
                self.report({'ERROR'}, "STL export failed — file is missing or empty.")
                set_ui_error("STL export failed — file is empty or missing.")
                return {'CANCELLED'}
            
            self.report({'INFO'}, f"Exported {obj.name} to {stl_path}")
            self.report({'INFO'}, "Successfully generated OpenFOAM dictionaries!")
            print(f"Mesh Generation Triggered. Case saved in: {case_dir}")
            
            utils_mesh.write_decompose_par(case_dir, props.cpu_cores)
            
            source_cmd = "source /usr/lib/openfoam/openfoam2412/etc/bashrc"
            if props.cpu_cores > 1:
                run_mesher = f"decomposePar -force && mpirun -np {props.cpu_cores} cartesianMesh -parallel && reconstructParMesh -constant && rm -rf processor*"
            else:
                run_mesher = "cartesianMesh"
                
            full_cmd = f"{source_cmd} && {run_mesher} && foamToSurface -constant constant/triSurface/result.stl"
            
            run_command_async(full_cmd, case_dir)
            self.report({'INFO'}, "Meshing started in background. Check 'Status' above.")
            
        except Exception as e:
            self.report({'ERROR'}, f"Python Error: {str(e)}")
            set_ui_error(f"Python: {str(e)[:50]}")
            print(f"Error during execution: {e}")
            
        return {'FINISHED'}
